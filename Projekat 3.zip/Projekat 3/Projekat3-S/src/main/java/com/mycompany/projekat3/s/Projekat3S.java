
package com.mycompany.projekat3.s;

import java.net.*;
import java.io.*;

public class Projekat3S {

    public static void main(String[] args) {
            int host=6666;
            
            if(args.length>0)
            {
                try{
                host=Integer.parseInt(args[0]);
                    }
                
            catch(NumberFormatException ex){}
            }
            
            try(ServerSocket server=new ServerSocket(host))
            {
                System.out.println("Ceka se...");
                
                while(true){
                    Socket veza=server.accept();
                    if(veza.isConnected()){System.out.println("Povezano");}
                    DataInputStream in=new DataInputStream(veza.getInputStream());
                    String podatak=in.readUTF();
                    System.out.println(podatak);
                    String [] podela=podatak.split("-");
                    int odgovor=Integer.parseInt(podela[0]);
                    int i=Integer.parseInt(podela[1]);
                    System.out.println(odgovor);
                    System.out.println(i);
                    in.close();
                    int tacnost=0;
                    
                    if(i==1)
                    {
                        if(odgovor==70){tacnost=1;}
                        else
                        {
                        tacnost=0;
                        }
                    }
                     if(i==2)
                    {
                        if(odgovor==400){tacnost=1;}
                        else
                        {
                        tacnost=0;
                        }
                    }
                      if(i==3)
                    {
                        if(odgovor==502){tacnost=1;}
                        else
                        {
                        tacnost=0;
                        }
                    }
                       if(i==4)
                    {
                        if(odgovor==535){tacnost=1;}
                        else
                        {
                        tacnost=0;
                        }
                    }
                        if(i==5)
                    {
                        if(odgovor==214){tacnost=1;}
                        else
                        {
                        tacnost=0;
                        }
                    }
                       DataOutputStream out=new DataOutputStream(veza.getOutputStream());
                       out.write(tacnost);
                       out.flush();
                       out.close();
                    }
            }
            catch(Exception e){
                System.out.println("Greska " + e.toString());
            }
                

}
}