package com.mycompany.projekat3.k;
import interfejs.Interfejs;
import java.io.*;
import java.net.*;


public class Projekat3K {

    public static void main(String[] args) {
       int host=6666;
       String hostname="localhost";
       Interfejs Intf=new Interfejs();
       if(args.length>0)
       {
           hostname=args[0];
       }
       
       try(Socket theSocket=new Socket(hostname,host))
       {
           System.out.println("Povezano");
           DataOutputStream out=new DataOutputStream(theSocket.getOutputStream());
           out.writeUTF(Intf.i+"-"+Intf.odgovor);
           out.flush();
           out.close();
           DataInputStream in=new DataInputStream(theSocket.getInputStream());
           Intf.tacnost=in.readInt();
           in.close();
           
       }
       catch(Exception e)
       {
           System.out.println("Greska");
       }
    }
}
